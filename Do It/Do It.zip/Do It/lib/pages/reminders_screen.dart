
import 'package:flutter/material.dart';



class RemindersPage extends StatefulWidget {
  const RemindersPage({ Key? key }) : super(key: key);

  @override
  State<RemindersPage> createState() => _RemindersPageState();
}

class _RemindersPageState extends State<RemindersPage> {
  @override
  Widget build(BuildContext context) {
    return Container(
      
    );
  }
}