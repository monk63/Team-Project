package com.example.do_it

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
